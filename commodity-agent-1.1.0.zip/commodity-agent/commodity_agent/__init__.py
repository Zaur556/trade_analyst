"""Commodity Signal Desk - buy/sell decision support for Brent, WTI, gold, silver, gas."""

__version__ = "1.1.0"
__all__ = ["__version__"]
